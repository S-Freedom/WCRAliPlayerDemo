var protocol_a_v_p_event_report_params_delegate_p =
[
    [ "onEventReportParams:", "d9/d4f/protocol_a_v_p_event_report_params_delegate-p.html#ad3c4b2ae50c23f74cb34c05abf927a37", null ]
];