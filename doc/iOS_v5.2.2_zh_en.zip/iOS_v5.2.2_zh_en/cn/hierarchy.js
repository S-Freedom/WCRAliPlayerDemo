var hierarchy =
[
    [ "_AVPStsInfo", "d4/dcf/struct___a_v_p_sts_info.html", null ],
    [ "AVPRenderCBWrapper", "d4/de0/class_a_v_p_render_c_b_wrapper.html", null ],
    [ "IEventReporter", null, [
      [ "EventReporterImpl", "d3/d13/class_event_reporter_impl.html", null ]
    ] ],
    [ "NSObject", null, [
      [ "AliMediaDownloader", "d0/d90/interface_ali_media_downloader.html", null ],
      [ "AliPlayer", "dc/da6/interface_ali_player.html", [
        [ "AliListPlayer", "da/d62/interface_ali_list_player.html", null ],
        [ "AVPLiveTimeShift", "db/d51/interface_a_v_p_live_time_shift.html", null ]
      ] ],
      [ "AliPlayerConan", "d3/db0/interface_ali_player_conan.html", null ],
      [ "AliPlayerGlobalSettings", "d1/d20/interface_ali_player_global_settings.html", null ],
      [ "AliPrivateService", "df/d18/interface_ali_private_service.html", null ],
      [ "AliSystemMediaPlayer", "d2/db5/interface_ali_system_media_player.html", null ],
      [ "AVDConfig", "d2/d25/interface_a_v_d_config.html", null ],
      [ "AVPCacheConfig", "d5/d33/interface_a_v_p_cache_config.html", null ],
      [ "AVPConfig", "d5/d6a/interface_a_v_p_config.html", null ],
      [ "AVPErrorModel", "d4/dee/interface_a_v_p_error_model.html", null ],
      [ "AVPLiveKeyGenerator", "d6/d90/interface_a_v_p_live_key_generator.html", null ],
      [ "AVPMediaInfo", "d2/d0d/interface_a_v_p_media_info.html", null ],
      [ "AVPSource", "de/d7f/interface_a_v_p_source.html", [
        [ "AVPLiveStsSource", "d6/d4e/interface_a_v_p_live_sts_source.html", null ],
        [ "AVPUrlSource", "dc/dbe/interface_a_v_p_url_source.html", null ],
        [ "AVPVidAuthSource", "d1/da1/interface_a_v_p_vid_auth_source.html", null ],
        [ "AVPVidMpsSource", "d4/d48/interface_a_v_p_vid_mps_source.html", null ],
        [ "AVPVidStsSource", "d8/d0c/interface_a_v_p_vid_sts_source.html", null ]
      ] ],
      [ "AVPThumbnailInfo", "db/de3/interface_a_v_p_thumbnail_info.html", null ],
      [ "AVPTimeShiftModel", "d3/dd3/interface_a_v_p_time_shift_model.html", null ],
      [ "AVPTrackInfo", "d0/d7f/interface_a_v_p_track_info.html", null ],
      [ "VidPlayerConfigGenerator", "dc/d4f/interface_vid_player_config_generator.html", null ]
    ] ],
    [ "<NSObject>", null, [
      [ "<AMDDelegate>", "d6/d92/protocol_a_m_d_delegate-p.html", null ],
      [ "<AVPDelegate>", "df/d03/protocol_a_v_p_delegate-p.html", null ],
      [ "<AVPEventReportParamsDelegate>", "d9/d4f/protocol_a_v_p_event_report_params_delegate-p.html", null ],
      [ "<AVPLiveKeyInfoDelegate>", "df/d94/protocol_a_v_p_live_key_info_delegate-p.html", null ]
    ] ]
];