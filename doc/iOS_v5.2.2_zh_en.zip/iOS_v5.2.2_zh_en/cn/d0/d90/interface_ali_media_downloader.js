var interface_ali_media_downloader =
[
    [ "deleteFile", "d0/d90/interface_ali_media_downloader.html#ae58862e333bad514784f2706eb1afc48", null ],
    [ "deleteFile:vid:format:index:", "d0/d90/interface_ali_media_downloader.html#ace991e451eda097b95d9f9df6ab8e6fe", null ],
    [ "destroy", "d0/d90/interface_ali_media_downloader.html#a34fa9cc437738b8599c603c50d2fa15c", null ],
    [ "getConfig", "d0/d90/interface_ali_media_downloader.html#a97de6e2f657fb2df3d1a9676c6bf1328", null ],
    [ "getSDKVersion", "d0/d90/interface_ali_media_downloader.html#a17f212a851117cd25e18eeb01f0752a1", null ],
    [ "init", "d0/d90/interface_ali_media_downloader.html#a073ec8f23990737100a6993bb459e8ae", null ],
    [ "prepareWithPlayAuth:", "d0/d90/interface_ali_media_downloader.html#a9203b080448d80465830171042ce69ae", null ],
    [ "prepareWithVid:", "d0/d90/interface_ali_media_downloader.html#a784ca5c429a07ab6d6ae243491c9119f", null ],
    [ "selectTrack:", "d0/d90/interface_ali_media_downloader.html#add7c135d885faf51672cfe097d416f24", null ],
    [ "setConfig:", "d0/d90/interface_ali_media_downloader.html#a03b9177edb3f39feb330ad20117ba67c", null ],
    [ "setPlayUrlConvertCallback:", "d0/d90/interface_ali_media_downloader.html#a047a9d74c3f05fe7f34d7a3816bde32d", null ],
    [ "setSaveDirectory:", "d0/d90/interface_ali_media_downloader.html#abdc227125a28c629f4ac62387959d4e7", null ],
    [ "start", "d0/d90/interface_ali_media_downloader.html#acd7e5244b6940b55df430a18fdccbb47", null ],
    [ "stop", "d0/d90/interface_ali_media_downloader.html#ac649dd77a4ca91cd096402969e7dfc16", null ],
    [ "updateWithPlayAuth:", "d0/d90/interface_ali_media_downloader.html#a6caf222155d86e60238beba8a65479d7", null ],
    [ "updateWithVid:", "d0/d90/interface_ali_media_downloader.html#ab72905609c21f1d5fd7c89ecea6e6b93", null ],
    [ "delegate", "d0/d90/interface_ali_media_downloader.html#a4b7ba206cd46ca381cbaefe2f2952f40", null ],
    [ "downloadedFilePath", "d0/d90/interface_ali_media_downloader.html#a40721f10a5452c4b2ea93ef938729f62", null ]
];