var interface_a_v_p_track_info =
[
    [ "audioChannels", "d0/d7f/interface_a_v_p_track_info.html#a83c566575a6a539a954570fa7befc600", null ],
    [ "audioLanguage", "d0/d7f/interface_a_v_p_track_info.html#af7fe32d4087e00a2962a48f895295f8b", null ],
    [ "audioSampleFormat", "d0/d7f/interface_a_v_p_track_info.html#a7ee9acfde9adcba293eb22bff10fe124", null ],
    [ "audioSamplerate", "d0/d7f/interface_a_v_p_track_info.html#aceb7448d2e182a75f60235367762df36", null ],
    [ "subtitleLanguage", "d0/d7f/interface_a_v_p_track_info.html#a32924a84f09051153e0a2a90c038d7cd", null ],
    [ "trackBitrate", "d0/d7f/interface_a_v_p_track_info.html#a1220b7ce0dc0100952e6422c449057f1", null ],
    [ "trackDefinition", "d0/d7f/interface_a_v_p_track_info.html#a9c5bae47b5540bf4cfd305f51a2d3312", null ],
    [ "trackIndex", "d0/d7f/interface_a_v_p_track_info.html#ae83c4882a386706ec3c081b2b0dd0a1b", null ],
    [ "trackType", "d0/d7f/interface_a_v_p_track_info.html#aceaa6c8ef2defae91059ceb8c0aa81f8", null ],
    [ "videoHeight", "d0/d7f/interface_a_v_p_track_info.html#a2f924d3f8e2609d86a47bc396922e153", null ],
    [ "videoWidth", "d0/d7f/interface_a_v_p_track_info.html#afbf9b3c84652726446fd5389db95a379", null ],
    [ "vodFileSize", "d0/d7f/interface_a_v_p_track_info.html#a4d2dc7a7cba0cec4ed220a3c11437f51", null ],
    [ "vodFormat", "d0/d7f/interface_a_v_p_track_info.html#af3fd1701de757518303f982bb5cecbf6", null ],
    [ "vodPlayUrl", "d0/d7f/interface_a_v_p_track_info.html#a8370bc9da88346a9aa08c05a455c3584", null ],
    [ "waterMarkUrl", "d0/d7f/interface_a_v_p_track_info.html#a302dfb91df851575d07406cce5c8f587", null ]
];