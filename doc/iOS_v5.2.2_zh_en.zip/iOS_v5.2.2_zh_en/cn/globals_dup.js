var globals_dup =
[
    [ "_", "globals.html", null ],
    [ "a", "globals_a.html", null ],
    [ "d", "globals_d.html", null ],
    [ "e", "globals_e.html", null ],
    [ "i", "globals_i.html", null ],
    [ "l", "globals_l.html", null ],
    [ "p", "globals_p.html", null ],
    [ "s", "globals_s.html", null ],
    [ "v", "globals_v.html", null ]
];