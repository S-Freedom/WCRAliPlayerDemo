var searchData=
[
  ['pause_631',['pause',['../dc/da6/interface_ali_player.html#a729028108333ff24d385c01dd7bc5f4a',1,'AliPlayer::pause()'],['../d2/db5/interface_ali_system_media_player.html#ad1be881a71584702f0568a335f23cdc8',1,'AliSystemMediaPlayer::pause()']]],
  ['prepare_632',['prepare',['../dc/da6/interface_ali_player.html#a07077d380681c5261ccd9ea7401dab8c',1,'AliPlayer']]],
  ['prepareasync_633',['prepareAsync',['../d2/db5/interface_ali_system_media_player.html#a31ca3cb814f1c8eb27d774b915f7651c',1,'AliSystemMediaPlayer']]],
  ['preparewithlivetimeurl_3a_634',['prepareWithLiveTimeUrl:',['../db/d51/interface_a_v_p_live_time_shift.html#a7dbfe2f08ad96b51c2d89c8d1d3c1d23',1,'AVPLiveTimeShift']]],
  ['preparewithplayauth_3a_635',['prepareWithPlayAuth:',['../d0/d90/interface_ali_media_downloader.html#a9203b080448d80465830171042ce69ae',1,'AliMediaDownloader']]],
  ['preparewithvid_3a_636',['prepareWithVid:',['../d0/d90/interface_ali_media_downloader.html#a784ca5c429a07ab6d6ae243491c9119f',1,'AliMediaDownloader']]]
];
