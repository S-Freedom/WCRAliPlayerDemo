var searchData=
[
  ['_5favpstsinfo_0',['_AVPStsInfo',['../d4/dcf/struct___a_v_p_sts_info.html',1,'']]],
  ['_5favpstsstatus_1',['_AVPStsStatus',['../db/dd9/_a_v_p_def_8h.html#a2ba5992fdea96753620edc1d07895173',1,'AVPDef.h']]]
];
