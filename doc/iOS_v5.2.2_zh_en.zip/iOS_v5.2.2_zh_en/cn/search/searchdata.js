var indexSectionsWithContent =
{
  0: "_abcdefghilmnopqrstuvw",
  1: "_aev",
  2: "aev",
  3: "acdefgimoprsuw",
  4: "afrst",
  5: "ap",
  6: "_a",
  7: "adeilpv",
  8: "abcdefhlmnpqrstuvw",
  9: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "properties",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Properties",
  9: "Pages"
};

