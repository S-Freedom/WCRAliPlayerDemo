var searchData=
[
  ['pending_918',['Pending',['../db/dd9/_a_v_p_def_8h.html#a2ba5992fdea96753620edc1d07895173a1f7a25007001fe77317521028b7af642',1,'AVPDef.h']]]
];
