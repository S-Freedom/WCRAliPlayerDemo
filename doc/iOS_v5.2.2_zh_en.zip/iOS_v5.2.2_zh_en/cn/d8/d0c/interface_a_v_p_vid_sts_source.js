var interface_a_v_p_vid_sts_source =
[
    [ "initWithVid:accessKeyId:accessKeySecret:securityToken:region:", "d8/d0c/interface_a_v_p_vid_sts_source.html#a7b3dc870d829bd80421022eeffd974e3", null ],
    [ "initWithVid:accessKeyId:accessKeySecret:securityToken:region:format:playConfig:", "d8/d0c/interface_a_v_p_vid_sts_source.html#a6001b818e3c7916436fb584cd6abb638", null ],
    [ "initWithVid:accessKeyId:accessKeySecret:securityToken:region:playConfig:", "d8/d0c/interface_a_v_p_vid_sts_source.html#a38e6b1fe04f63fbfb0910601e980e44e", null ],
    [ "accessKeyId", "d8/d0c/interface_a_v_p_vid_sts_source.html#a442025ca73e5c42934e589f76c1121a9", null ],
    [ "accessKeySecret", "d8/d0c/interface_a_v_p_vid_sts_source.html#acf2816f723616268411a0708b9cac829", null ],
    [ "format", "d8/d0c/interface_a_v_p_vid_sts_source.html#ab7cb325bcfb8fae0d53e400baeaceaba", null ],
    [ "playConfig", "d8/d0c/interface_a_v_p_vid_sts_source.html#a4c58dcf3ed0c8d02b26c40cc47da4364", null ],
    [ "region", "d8/d0c/interface_a_v_p_vid_sts_source.html#a493bf327d6ace26168f91ac116546ad0", null ],
    [ "securityToken", "d8/d0c/interface_a_v_p_vid_sts_source.html#a9815f53b4c1e1be8e7f7777b7391d210", null ],
    [ "vid", "d8/d0c/interface_a_v_p_vid_sts_source.html#a4a676b68e1f7ee41af96acc46d141bd5", null ]
];