var interface_ali_list_player =
[
    [ "addUrlSource:uid:", "da/d62/interface_ali_list_player.html#a2b77e38afca8055b1fc7aacfdd6102ee", null ],
    [ "addVidSource:uid:", "da/d62/interface_ali_list_player.html#acbea80930bac245f375f4dcffe5a1d9e", null ],
    [ "clear", "da/d62/interface_ali_list_player.html#a9a2b87d2983120023b03559004af4971", null ],
    [ "currentUid", "da/d62/interface_ali_list_player.html#ae19896ff3f272644b7baf44a169c0e6d", null ],
    [ "init", "da/d62/interface_ali_list_player.html#aeb9b7c0ea8f3f8de06ba4afc2a0eee93", null ],
    [ "init:", "da/d62/interface_ali_list_player.html#afe914f86eb7f19329972158a529339b9", null ],
    [ "moveTo:", "da/d62/interface_ali_list_player.html#acf6818f7b5a8d96698262179eb4d7c36", null ],
    [ "moveTo:accId:accKey:token:region:", "da/d62/interface_ali_list_player.html#a16393cae407a4f2530327ed2e1ad4f9f", null ],
    [ "moveToNext", "da/d62/interface_ali_list_player.html#a67673971626ec35c0f5a2019dc2f7d72", null ],
    [ "moveToNext:accKey:token:region:", "da/d62/interface_ali_list_player.html#a206013c09f893fa7007140dfdd053366", null ],
    [ "moveToPre", "da/d62/interface_ali_list_player.html#a303cc70f4936e57bc0be67fbb6a16f9d", null ],
    [ "moveToPre:accKey:token:region:", "da/d62/interface_ali_list_player.html#a44ae6126fd212d80789aaee105c21e93", null ],
    [ "removeSource:", "da/d62/interface_ali_list_player.html#a4a8405f42b8449e451ea1b565fd87d81", null ],
    [ "maxPreloadMemorySizeMB", "da/d62/interface_ali_list_player.html#a31e35178c328878a79ae162ef180550a", null ],
    [ "preloadCount", "da/d62/interface_ali_list_player.html#ac8d3576f883ed8580c1410da0f6b5df3", null ],
    [ "stsPreloadDefinition", "da/d62/interface_ali_list_player.html#a590832371d64b43f18bbbd114c8a8173", null ]
];