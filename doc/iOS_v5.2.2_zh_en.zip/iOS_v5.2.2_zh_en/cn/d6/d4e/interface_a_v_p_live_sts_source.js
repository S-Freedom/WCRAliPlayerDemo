var interface_a_v_p_live_sts_source =
[
    [ "initWithUrl:accessKeyId:accessKeySecret:securityToken:region:domain:app:stream:", "d6/d4e/interface_a_v_p_live_sts_source.html#a4349796e52131b0cc7ced91a5d219500", null ],
    [ "accessKeyId", "d6/d4e/interface_a_v_p_live_sts_source.html#aac01f33ddfa6985ef765756570005607", null ],
    [ "accessKeySecret", "d6/d4e/interface_a_v_p_live_sts_source.html#a0788b10cbd37c6e2c93c866d63c1a748", null ],
    [ "app", "d6/d4e/interface_a_v_p_live_sts_source.html#aa67c9cdae8b2a1e52809768acef89b25", null ],
    [ "domain", "d6/d4e/interface_a_v_p_live_sts_source.html#a81ceead0384c3bb792c0c3cf2ac0b87f", null ],
    [ "region", "d6/d4e/interface_a_v_p_live_sts_source.html#aa2e96cf90f60a5e85c874639557699fb", null ],
    [ "securityToken", "d6/d4e/interface_a_v_p_live_sts_source.html#ad874e1dd340f3aa29f457244cddfd355", null ],
    [ "stream", "d6/d4e/interface_a_v_p_live_sts_source.html#a6a5b661195373ddbde0fca7023df5e23", null ],
    [ "url", "d6/d4e/interface_a_v_p_live_sts_source.html#a1e8543e4b9d21fda47d7fac3dac0678d", null ]
];