var protocol_a_m_d_delegate_p =
[
    [ "onCompletion:", "d6/d92/protocol_a_m_d_delegate-p.html#abd22acbfdac50f0112fd046c0fb5eb68", null ],
    [ "onDownloadingProgress:percentage:", "d6/d92/protocol_a_m_d_delegate-p.html#a1e02afdcc80561408c60b6167ad77239", null ],
    [ "onError:errorModel:", "d6/d92/protocol_a_m_d_delegate-p.html#af9d2767f7fcfb803f5a399f608d9cc7d", null ],
    [ "onPrepared:mediaInfo:", "d6/d92/protocol_a_m_d_delegate-p.html#a49ab72794ab7a5c28643b81a1b186b74", null ],
    [ "onProcessingProgress:percentage:", "d6/d92/protocol_a_m_d_delegate-p.html#af6668792dc1e8665800ee69c5218cc5b", null ]
];