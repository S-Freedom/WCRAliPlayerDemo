var interface_ali_player_global_settings =
[
    [ "setDNSResolve:ip:", "d1/d20/interface_ali_player_global_settings.html#a8e11790555758d4d534a0f1e26939b26", null ],
    [ "setFairPlayCertID:", "d1/d20/interface_ali_player_global_settings.html#a5d44635fa1a781ef31b40e649e64f332", null ],
    [ "setIpResolveType:", "d1/d20/interface_ali_player_global_settings.html#a5e03f1930b4b888fb7ce9e213febd4df", null ]
];