var interface_ali_private_service =
[
    [ "initKey:", "df/d18/interface_ali_private_service.html#a8d2643711a9460fea65ca84c20c0b1e7", null ],
    [ "initKeyWithData:", "df/d18/interface_ali_private_service.html#a4dec6a81c62c41eb93eff92fdb14bceb", null ]
];