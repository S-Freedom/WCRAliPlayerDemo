var protocol_a_v_p_delegate_p =
[
    [ "onBufferedPositionUpdate:position:", "df/d03/protocol_a_v_p_delegate-p.html#a3fc381f570349d7670b03710e07f0d78", null ],
    [ "onCaptureScreen:image:", "df/d03/protocol_a_v_p_delegate-p.html#aa4ccd7788722da1160b7fc60dd3ffcfe", null ],
    [ "onCurrentPositionUpdate:position:", "df/d03/protocol_a_v_p_delegate-p.html#a04f5fa92c8cac380f75e62fdc201d203", null ],
    [ "onError:errorModel:", "df/d03/protocol_a_v_p_delegate-p.html#aec89e835332f35298cf554703f128256", null ],
    [ "onGetThumbnailFailed:", "df/d03/protocol_a_v_p_delegate-p.html#ae07c439d42ae4a3f5d03ee5df4564b22", null ],
    [ "onGetThumbnailSuc:fromPos:toPos:image:", "df/d03/protocol_a_v_p_delegate-p.html#acd2d49455568ab5631d7d07346945318", null ],
    [ "onLoadingProgress:progress:", "df/d03/protocol_a_v_p_delegate-p.html#aacd3411469bc1a4fff254d3af3e55730", null ],
    [ "onPlayerEvent:eventType:", "df/d03/protocol_a_v_p_delegate-p.html#a5e0d640031bfd6a84cae694bb907edb9", null ],
    [ "onPlayerEvent:eventWithString:description:", "df/d03/protocol_a_v_p_delegate-p.html#af6d52a7b14fda06f7fa532fdbf9817cd", null ],
    [ "onPlayerStatusChanged:oldStatus:newStatus:", "df/d03/protocol_a_v_p_delegate-p.html#a827f9ce696170ecff849c3db6c9ac91a", null ],
    [ "onSEIData:type:data:", "df/d03/protocol_a_v_p_delegate-p.html#a8e845685c3806d9ce2f4fb9c40146e38", null ],
    [ "onSubtitleExtAdded:trackIndex:URL:", "df/d03/protocol_a_v_p_delegate-p.html#a32bc5e40c64155199a5c4bcfa2ff2ef8", null ],
    [ "onSubtitleHide:trackIndex:subtitleID:", "df/d03/protocol_a_v_p_delegate-p.html#a3807a4cd17d619f47d65a33b54ad53e3", null ],
    [ "onSubtitleShow:trackIndex:subtitleID:subtitle:", "df/d03/protocol_a_v_p_delegate-p.html#a1b771c3aef810dd6875ac5566c9424a0", null ],
    [ "onTrackChanged:info:", "df/d03/protocol_a_v_p_delegate-p.html#aeb53ac78525ee9b0e002ee8f6d7154ae", null ],
    [ "onTrackReady:info:", "df/d03/protocol_a_v_p_delegate-p.html#a062a598422865d07a62579e09d313fb6", null ],
    [ "onVideoRendered:timeMs:pts:", "df/d03/protocol_a_v_p_delegate-p.html#a8328e9ba362ea7b1eb6357d20c99ad23", null ],
    [ "onVideoSizeChanged:width:height:rotation:", "df/d03/protocol_a_v_p_delegate-p.html#afc50b6a8a5f67ffb9fbede3093f906ff", null ]
];