var protocol_a_v_p_live_key_info_delegate_p =
[
    [ "onGetLiveKey:", "df/d94/protocol_a_v_p_live_key_info_delegate-p.html#a5c8c40631087603a294edbded6c77931", null ],
    [ "onLiveKeyInfo:ekeyPreGenTime:", "df/d94/protocol_a_v_p_live_key_info_delegate-p.html#ac78e3d16df9b403f14b4aa5ef128fc3e", null ]
];