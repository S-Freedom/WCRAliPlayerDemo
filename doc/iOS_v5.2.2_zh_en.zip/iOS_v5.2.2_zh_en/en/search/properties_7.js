var searchData=
[
  ['livestartindex_958',['liveStartIndex',['../d5/d6a/interface_a_v_p_config.html#a62d50848b79fa585d81a9474046d8d5c',1,'AVPConfig']]],
  ['livetime_959',['liveTime',['../db/d51/interface_a_v_p_live_time_shift.html#a79bac3a8e783b566158dec5aa2842a1e',1,'AVPLiveTimeShift']]],
  ['loop_960',['loop',['../dc/da6/interface_ali_player.html#ac6d3f64d247125e3d5c652945193f551',1,'AliPlayer']]]
];
