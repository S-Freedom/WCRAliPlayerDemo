var searchData=
[
  ['addextsubtitle_3a_557',['addExtSubtitle:',['../dc/da6/interface_ali_player.html#a2b38d82a3ed151badbf8cd029840cf2b',1,'AliPlayer']]],
  ['addurlsource_3auid_3a_558',['addUrlSource:uid:',['../da/d62/interface_ali_list_player.html#a2b77e38afca8055b1fc7aacfdd6102ee',1,'AliListPlayer']]],
  ['addvidplayerconfigbyintvalue_3avalue_3a_559',['addVidPlayerConfigByIntValue:value:',['../dc/d4f/interface_vid_player_config_generator.html#a467aef0ead5d3e787b9b820eaab0dfac',1,'VidPlayerConfigGenerator']]],
  ['addvidplayerconfigbystringvalue_3avalue_3a_560',['addVidPlayerConfigByStringValue:value:',['../dc/d4f/interface_vid_player_config_generator.html#ab1a769ac927396b5cefcd12e83a01ed6',1,'VidPlayerConfigGenerator']]],
  ['addvidsource_3auid_3a_561',['addVidSource:uid:',['../da/d62/interface_ali_list_player.html#acbea80930bac245f375f4dcffe5a1d9e',1,'AliListPlayer']]]
];
