var searchData=
[
  ['accid_684',['accId',['../d4/dcf/struct___a_v_p_sts_info.html#a99b0f7cb69ae549b1172152bd1cd8753',1,'_AVPStsInfo']]],
  ['accsecret_685',['accSecret',['../d4/dcf/struct___a_v_p_sts_info.html#aa06fcce61b9dafe565b23f41e82f34b0',1,'_AVPStsInfo']]]
];
